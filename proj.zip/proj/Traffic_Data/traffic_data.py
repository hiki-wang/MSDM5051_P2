import pandas as pd
# import numpy as np
import matplotlib.pyplot as plt
from typing import Union, List
from IPython.display import display

pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None)
pd.set_option('display.width', 200)


# 该类仅保存单一文件（小时）中的数据
class Traffic_Data:
    def __init__(self, df):
        self.columns_list = ['VehicleType', 'DerectionTime_O', 'GantryID_O', 'DerectionTime_D', 'GantryID_D',
                             'TripLength', 'TripEnd', 'TripInformation']
        df.dropna(how='all', axis=0, inplace=True)
        df.columns = self.columns_list
        df['DerectionTime_O'] = pd.to_datetime(df['DerectionTime_O'])
        df['DerectionTime_D'] = pd.to_datetime(df['DerectionTime_D'])
        self.df = df

    # 由于没要求删数据，因此我只重载了加法运算符
    def __add__(self, other):
        if isinstance(other, Traffic_Data):
            new_df = pd.concat([self.df, other.df], ignore_index=True)
            return Traffic_Data(new_df)
        elif isinstance(other, pd.DataFrame):
            new_df = pd.concat([self.df, other], ignore_index=True)
            return Traffic_Data(new_df)
        else:
            raise TypeError('Operand must be an instance of Traffic_Data')

    def search(self, start_time: str = '00:00:00', end_time: str = '12:00:00', vehicle_type: int = 31,
               default_date: str = '2023-12-04'):
        """
        不需要设计多日搜索，因为数据都在同一天
        :param start_time: 搜索开始时间
        :param end_time: 搜索结束时间
        :param vehicle_type: 车辆类型
        :return: 所需数据的Traffic_Data对象
        """
        # 若只输入了时刻

        if (len(start_time) == 8):
            start_time = f"{default_date} {start_time}"
        if (len(end_time) == 8):
            end_time = f"{default_date} {end_time}"
        # 转为datetime
        start_time = pd.to_datetime(start_time)
        end_time = pd.to_datetime(end_time)
        # 筛选
        filter = self.df[(self.df['DerectionTime_O'] >= start_time) & (self.df['DerectionTime_D'] <= end_time) & (
                self.df['VehicleType'] == vehicle_type)].copy()
        return Traffic_Data(filter)

    # 为什么需要返回值？因为我们大概率之后还要写前端，而不是直接在notebook或console上看结果。
    def display(self, n_row: int = 10, display_all=False, random=False):
        if display_all:
            print('too large, please wait...')
            display(self.df)
            return self
        else:
            if random == True:
                sample_df = self.df.sample(n=n_row).copy()
                display(sample_df)
                return Traffic_Data(sample_df)
            else:
                sample_df = self.df.iloc[:n_row].copy()
                display(sample_df)
                return Traffic_Data(sample_df)

    # 排序函数，输入列名和列位置均可
    # 至于具体的sort算法，我的评价是自己怎么写都不如内置的快，干脆不写
    def sort(self, sort_by: Union[int, str] = 'DerectionTime_O', ascending=True):
        if isinstance(sort_by, int):
            sort_by = self.columns_list[sort_by]
        sorted_df = self.df.sort_values(sort_by, ascending=ascending)
        return Traffic_Data(sorted_df)

    # 这里就不做filter了, 因为前面有search。想只export部分的可以search。
    def export(self, type: str = 'csv'):
        if type == 'csv':
            pd.DataFrame.to_csv(self.df, index=False)
        elif type == 'excel':
            pd.DataFrame.to_excel(self.df, index=False)
        elif type == 'pickle':
            pd.DataFrame.to_pickle(self.df, index=False)
        return

    # 下面可以加一些其他函数，例如数据的各种描述性统计，如：每分钟车辆个数的频率分布直方图、不同type车辆的直方图、TripLength的五数概括、平均值等等
    # 这里只给出一个,之后需要看情况添加/修改（例如增加返回值、保存图片到本地等），因为我们要写前端
    def plot_minute_counts(self):
        df = self.df.copy()
        df['Minute'] = df['DerectionTime_O'].dt.minute
        minute_counts = df['Minute'].value_counts().sort_index()
        plt.figure(figsize=(12, 6))
        plt.bar(minute_counts.index, minute_counts.values, color='skyblue')
        plt.title('Number of VehicleTypes per Minute')
        plt.xlabel('Minute')
        plt.ylabel('Number of VehicleTypes')
        plt.xticks(range(60))
        plt.grid(axis='y')
        plt.show()
        return
