import tkinter as tk
from tkinter import filedialog, messagebox
import pandas as pd
import matplotlib.pyplot as plt
from traffic_data import Traffic_Data
from traffic_data_hours import Traffic_Data_hours

root = tk.Tk()
root.title("Traffic Data Manager")
root.geometry("800x600")

current_data = None

menu_bar = tk.Menu(root)
root.config(menu=menu_bar)

file_menu = tk.Menu(menu_bar, tearoff=0)
menu_bar.add_cascade(label="File", menu=file_menu)
file_menu.add_command(label="Open", command=lambda: load_data())
file_menu.add_command(label="Export", command=lambda: export_data())
file_menu.add_separator()
file_menu.add_command(label="Exit", command=root.quit)

button_frame = tk.Frame(root)
button_frame.pack(side=tk.TOP, fill=tk.X)

btn_load = tk.Button(button_frame, text="Load Data", command=lambda: load_data())
btn_load.pack(side=tk.LEFT, padx=5, pady=5)

btn_search = tk.Button(button_frame, text="Search", command=lambda: search_data())
btn_search.pack(side=tk.LEFT, padx=5, pady=5)

btn_sort = tk.Button(button_frame, text="Sort", command=lambda: sort_data())
btn_sort.pack(side=tk.LEFT, padx=5, pady=5)

btn_append = tk.Button(button_frame, text="Append Data", command=lambda: append_data())
btn_append.pack(side=tk.LEFT, padx=5, pady=5)

btn_plot = tk.Button(button_frame, text="Plot", command=lambda: plot_data())
btn_plot.pack(side=tk.LEFT, padx=5, pady=5)

data_display = tk.Text(root, wrap=tk.NONE)
data_display.pack(fill=tk.BOTH, expand=True)

scrollbar_x = tk.Scrollbar(data_display, orient=tk.HORIZONTAL)
scrollbar_y = tk.Scrollbar(data_display, orient=tk.VERTICAL)
data_display.config(xscrollcommand=scrollbar_x.set, yscrollcommand=scrollbar_y.set)
scrollbar_x.pack(side=tk.BOTTOM, fill=tk.X)
scrollbar_y.pack(side=tk.RIGHT, fill=tk.Y)


def load_data():
    global current_data
    file_paths = filedialog.askopenfilenames(filetypes=[("CSV files", "*.csv")])
    if file_paths:
        current_data = Traffic_Data_hours(list(file_paths))
        display_data(n_row=30)


def search_data():
    if current_data:
        # 创建搜索对话框
        search_dialog = tk.Toplevel(root)
        search_dialog.title("Search Data")

        tk.Label(search_dialog, text="Start Time:").grid(row=0, column=0)
        start_time_entry = tk.Entry(search_dialog)
        start_time_entry.grid(row=0, column=1)

        tk.Label(search_dialog, text="End Time:").grid(row=1, column=0)
        end_time_entry = tk.Entry(search_dialog)
        end_time_entry.grid(row=1, column=1)

        tk.Label(search_dialog, text="Vehicle Type:").grid(row=2, column=0)
        vehicle_type_entry = tk.Entry(search_dialog)
        vehicle_type_entry.grid(row=2, column=1)

        def do_search():
            start_time = start_time_entry.get()
            end_time = end_time_entry.get()
            vehicle_type = int(vehicle_type_entry.get())
            search_result = current_data.search(start_time=start_time, end_time=end_time, vehicle_type=vehicle_type)
            display_data(data=search_result.Data.df)
            search_dialog.destroy()

        search_button = tk.Button(search_dialog, text="Search", command=do_search)
        search_button.grid(row=3, columnspan=2)
    else:
        messagebox.showwarning("No Data", "Please load data first.")


def sort_data():
    if current_data:
        # 创建排序对话框
        sort_dialog = tk.Toplevel(root)
        sort_dialog.title("Sort Data")

        tk.Label(sort_dialog, text="Sort By:").grid(row=0, column=0)
        sort_by_var = tk.StringVar()
        sort_by_options = ['DerectionTime_O', 'DerectionTime_D', 'VehicleType', 'GantryID_O', 'GantryID_D']
        sort_by_menu = tk.OptionMenu(sort_dialog, sort_by_var, *sort_by_options)
        sort_by_menu.grid(row=0, column=1)

        tk.Label(sort_dialog, text="Ascending:").grid(row=1, column=0)
        ascending_var = tk.BooleanVar()
        ascending_check = tk.Checkbutton(sort_dialog, variable=ascending_var)
        ascending_check.grid(row=1, column=1)

        def do_sort():
            sort_by = sort_by_var.get()
            ascending = ascending_var.get()
            sorted_data = current_data.sort(sort_by=sort_by, ascending=ascending)
            display_data(data=sorted_data.Data.df)
            sort_dialog.destroy()

        sort_button = tk.Button(sort_dialog, text="Sort", command=do_sort)
        sort_button.grid(row=2, columnspan=2)
    else:
        messagebox.showwarning("No Data", "Please load data first.")


def append_data():
    if current_data:
        file_path = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
        if file_path:
            df = pd.read_csv(file_path, header=None)
            current_data.append(Traffic_Data(df))
            display_data(n_row=10)
    else:
        messagebox.showwarning("No Data", "Please load data first.")


def plot_data():
    if current_data:
        # 创建绘图选择对话框
        plot_dialog = tk.Toplevel(root)
        plot_dialog.title("Plot Data")

        tk.Label(plot_dialog, text="Select Plot:").grid(row=0, column=0)
        plot_var = tk.StringVar()
        plot_options = ['Minute Counts', 'Hourly Counts']
        plot_menu = tk.OptionMenu(plot_dialog, plot_var, *plot_options)
        plot_menu.grid(row=0, column=1)

        def do_plot():
            plot_type = plot_var.get()
            if plot_type == 'Minute Counts':
                current_data.Data.plot_minute_counts()
            elif plot_type == 'Hourly Counts':
                current_data.plot_hourly_counts()
            plot_dialog.destroy()

        plot_button = tk.Button(plot_dialog, text="Plot", command=do_plot)
        plot_button.grid(row=1, columnspan=2)
    else:
        messagebox.showwarning("No Data", "Please load data first.")


def export_data():
    if current_data:
        file_path = filedialog.asksaveasfilename(defaultextension=".csv",
                                                 filetypes=[("CSV files", "*.csv"),
                                                            ("Excel files", "*.xlsx"),
                                                            ("Pickle files", "*.pkl")])
        if file_path:
            file_type = file_path.split('.')[-1]
            current_data.export(type=file_type, file_path=file_path)
            messagebox.showinfo("Export", "Data exported successfully.")
    else:
        messagebox.showwarning("No Data", "Please load data first.")


def display_data(n_row=10, data=None):
    data_display.delete(1.0, tk.END)
    if data is None and current_data:
        data = current_data.Data.df
    data_display.insert(tk.END, data.head(n_row).to_string())


root.mainloop()