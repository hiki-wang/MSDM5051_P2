import pandas as pd
from traffic_data import Traffic_Data
import matplotlib.pyplot as plt
from typing import Union, List

pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None)
pd.set_option('display.width', 200)


# 用于管理data的类，读取数据文件、合并数据等
class Traffic_Data_hours:
    # 用路径名、路径列表、Traffic_Data初始化均可。暂不考虑用Dataframe初始化，没什么意义。
    def __init__(self, init_input: Union[List, str, Traffic_Data]):
        if isinstance(init_input, Traffic_Data):
            self.Data = init_input
        else:
            if isinstance(init_input, str):
                init_input = [init_input]
            df = pd.read_csv(init_input[0], header=None)
            Data = Traffic_Data(df)
            for path in init_input[1:]:
                Data_temp = pd.read_csv(path, header=None)
                Data = Data + Traffic_Data(Data_temp)
            self.Data = Data

    def append(self, other):
        if isinstance(other, Traffic_Data_hours):
            self.Data = self.Data + other.Data
        elif isinstance(other, (Traffic_Data, pd.DataFrame)):
            self.Data = self.Data + other
        else:
            raise TypeError('Operand must be an instance of Traffic_Data_hours/Traffic_Data/DataFrame')

    def search(self, start_time: str = '00:00:00', end_time: str = '12:00:00', vehicle_type: int = 31,
               default_date: str = '2023-12-04'):
        return Traffic_Data_hours(self.Data.search(start_time=start_time, end_time=end_time, vehicle_type=vehicle_type,
                                                   default_date=default_date))

    def display(self, n_row: int = 10, display_all=False):
        return Traffic_Data_hours(self.Data.display(n_row=n_row, display_all=display_all))

    def sort(self, sort_by: Union[int, str] = 'DerectionTime_O', ascending=True):
        return Traffic_Data_hours(self.Data.sort(sort_by=sort_by, ascending=ascending))

    def export(self, type: str = 'csv'):
        Traffic_Data_hours(self.Data.export(type=type))
        return

    def plot_hourly_counts(self):
        df = self.Data.df.copy()
        df['DerectionTime_O'] = pd.to_datetime(df['DerectionTime_O'])
        df['Hour'] = df['DerectionTime_O'].dt.hour
        hourly_counts = df['Hour'].value_counts().sort_index()
        plt.figure(figsize=(12, 6))
        plt.bar(hourly_counts.index, hourly_counts.values, color='skyblue')
        plt.title('Number of VehicleTypes per Hour')
        plt.xlabel('Hour')
        plt.ylabel('Number of VehicleTypes')
        plt.xticks(range(24))
        plt.grid(axis='y')
        plt.show()
        return
